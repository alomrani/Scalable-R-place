index.handler = async (event) => {
    // TODO implement
	var dim = 100; // note: this is not the right dimensions!!
    var database = require("pg");
    var redis = require('redis');
    var config = require("./config.json");
    
    var dbConfig = {
            user: 'postgres',
            password: 'postgres',
            database: 'postgres',
            host: 'database.cqfkjyldqfdo.us-east-2.rds.amazonaws.com',
            port: 5432
    };
    var DBclient = new database.Client(dbConfig);
    var publisher = redis.createClient(config.redisClusterPort, config.redisClusterHost);
    
    let query = DBclient.query("SELECT * from board;");
	query.then(function (result) {
		let jsonString = JSON.stringify(result.rows);
		let DBboard = JSON.parse(jsonString)[0]["board"]; // 100 by 100 array
		for(let x=0;x<dim;x++){
			for(let y=0;y<dim;y++) {
				var r = Math.floor((255-DBboard[x][y].r)/32) * 64
				var g = Math.floor((255-DBboard[x][y].g)/32) * 8
				var b = Math.floor((255-DBboard[x][y].b)/32)
				let rgb = r+g+b;
				//console.log(r);
				publisher.send_command("BITFIELD", ["board","SET","u9",(y*dim+x)*9,rgb]);
				//ws.send(JSON.stringify(o));
			}
		}
	console.log("database sync");
	}).catch((err) => {
			console.log(err);
	});	
};

